import './App.css';
// import Button from 'react-bootstrap/Button';
import { Container } from './components/Container';

function App() {
  return (
    <Container/>
  );
}

export default App;